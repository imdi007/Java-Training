package project.EmployeeManagementSystem.oauthserver.EmployeeManagementSystemOauthServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystemOauthServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemOauthServerApplication.class, args);
	}

}
